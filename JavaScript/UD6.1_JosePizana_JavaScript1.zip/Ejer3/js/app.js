let clave = Math.floor(Math.random() * 5) + 1;

function cifrar(mensaje, desplazamiento = clave) {
    
    mensaje = mensaje.toLowerCase();
    
    // Variable para guardar el resultado
    let resultado = '';
    
    // Recorrer cada carácter del mensaje
    for (const element of mensaje) {
        let char = element;
        
        // Verificar si es una letra
        if (char >= 'a' && char <= 'z') {
            
            let codigo = char.charCodeAt(0);
            
            // Restar para obtener posición (0-25)
            let posicion = codigo - 'a'.charCodeAt(0);
            
            // Sumar el desplazamiento
            posicion = posicion + desplazamiento;
            
            // Dar la vuelta si se pasa
            posicion = posicion % 26;
            
            // Convertir de vuelta a letra
            let letraCifrada = String.fromCharCode(posicion + 'a'.charCodeAt(0));
            
            resultado = resultado + letraCifrada;
        } else {
            // Si no es letra, añadirla sin cambios
            resultado = resultado + char;
        }
    }
    
    return resultado;
}

console.log('Clave utilizada:', clave);
console.log('Mensaje original: hola mundo');
console.log('Cifrado:', cifrar('hola mundo', clave));